elliot.evaluation.metrics.coverage.item\_coverage package
=========================================================

Submodules
----------

elliot.evaluation.metrics.coverage.item\_coverage.item\_coverage module
-----------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.coverage.item_coverage.item_coverage
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.coverage.item_coverage
   :members:
   :undoc-members:
   :show-inheritance:
