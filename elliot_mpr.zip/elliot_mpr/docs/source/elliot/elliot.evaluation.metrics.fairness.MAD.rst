elliot.evaluation.metrics.fairness.MAD package
==============================================

Submodules
----------

elliot.evaluation.metrics.fairness.MAD.ItemMADranking module
------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.MAD.ItemMADranking
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.fairness.MAD.ItemMADrating module
-----------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.MAD.ItemMADrating
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.fairness.MAD.UserMADranking module
------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.MAD.UserMADranking
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.fairness.MAD.UserMADrating module
-----------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.MAD.UserMADrating
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.fairness.MAD
   :members:
   :undoc-members:
   :show-inheritance:
