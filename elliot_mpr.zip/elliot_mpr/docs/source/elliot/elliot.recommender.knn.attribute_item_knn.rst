elliot.recommender.knn.attribute\_item\_knn package
==================================================

Submodules
----------

elliot.recommender.knn.attribute\_item\_knn.attribute\_item\_knn module
----------------------------------------------------------------------

.. automodule:: elliot.recommender.knn.attribute_item_knn.attribute_item_knn
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knn.attribute\_item\_knn.attribute\_item\_knn\_similarity module
----------------------------------------------------------------------------------

.. automodule:: elliot.recommender.knn.attribute_item_knn.attribute_item_knn_similarity
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.knn.attribute_item_knn
   :members:
   :undoc-members:
   :show-inheritance:
