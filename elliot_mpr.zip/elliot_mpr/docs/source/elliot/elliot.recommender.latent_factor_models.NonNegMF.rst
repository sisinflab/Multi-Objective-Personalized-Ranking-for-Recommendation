elliot.recommender.latent\_factor\_models.NonNegMF package
==========================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.NonNegMF.non\_negative\_matrix\_factorization module
----------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.NonNegMF.non_negative_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.NonNegMF.non\_negative\_matrix\_factorization\_model module
-----------------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.NonNegMF.non_negative_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.NonNegMF
   :members:
   :undoc-members:
   :show-inheritance:
