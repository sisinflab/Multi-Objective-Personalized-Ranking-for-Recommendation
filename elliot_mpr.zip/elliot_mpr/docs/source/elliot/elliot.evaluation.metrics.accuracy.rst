elliot.evaluation.metrics.accuracy package
==========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics.accuracy.AUC
   elliot.evaluation.metrics.accuracy.DSC
   elliot.evaluation.metrics.accuracy.f1
   elliot.evaluation.metrics.accuracy.hit_rate
   elliot.evaluation.metrics.accuracy.map
   elliot.evaluation.metrics.accuracy.mar
   elliot.evaluation.metrics.accuracy.mrr
   elliot.evaluation.metrics.accuracy.ndcg
   elliot.evaluation.metrics.accuracy.precision
   elliot.evaluation.metrics.accuracy.recall

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy
   :members:
   :undoc-members:
   :show-inheritance:
