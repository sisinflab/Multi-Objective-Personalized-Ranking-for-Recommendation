elliot.recommender.latent\_factor\_models.FISM package
======================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.FISM.FISM module
----------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FISM.FISM
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.FISM.FISM\_model module
-----------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FISM.FISM_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.FISM
   :members:
   :undoc-members:
   :show-inheritance:
