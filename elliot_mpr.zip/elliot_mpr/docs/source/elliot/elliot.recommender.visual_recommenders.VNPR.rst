elliot.recommender.visual\_recommenders.VNPR package
====================================================

Submodules
----------

elliot.recommender.visual\_recommenders.VNPR.VNPR module
-----------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.VNPR.VNPR
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.visual\_recommenders.VNPR.VNPR\_model module
------------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.VNPR.VNPR_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.visual_recommenders.VNPR
   :members:
   :undoc-members:
   :show-inheritance:
