elliot.recommender.adversarial.AMF package
==========================================

Submodules
----------

elliot.recommender.adversarial.AMF.AMF module
---------------------------------------------

.. automodule:: elliot.recommender.adversarial.AMF.AMF
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.adversarial.AMF.AMF\_model module
----------------------------------------------------

.. automodule:: elliot.recommender.adversarial.AMF.AMF_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.adversarial.AMF
   :members:
   :undoc-members:
   :show-inheritance:
