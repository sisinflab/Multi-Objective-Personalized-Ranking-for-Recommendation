elliot.evaluation.metrics.bias.pop\_rsp package
===============================================

Submodules
----------

elliot.evaluation.metrics.bias.pop\_rsp.extended\_pop\_rsp module
-----------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.bias.pop_rsp.extended_pop_rsp
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.bias.pop\_rsp.pop\_rsp module
-------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.bias.pop_rsp.pop_rsp
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.bias.pop_rsp
   :members:
   :undoc-members:
   :show-inheritance:
