elliot.evaluation.metrics.accuracy.ndcg package
================================================

Submodules
----------

elliot.evaluation.metrics.accuracy.ndcg.ndcg module
-----------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.ndcg.ndcg
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.ndcg
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.accuracy.ndcg.ndcg_rendle2020 module
---------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.ndcg.ndcg_rendle2020
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.ndcg.ndcg_rendle2020
   :members:
   :undoc-members:
   :show-inheritance: