elliot.recommender.neural.ConvMF package
========================================

Submodules
----------

elliot.recommender.neural.ConvMF.convolutional\_matrix\_factorization module
----------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.ConvMF.convolutional_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.ConvMF.convolutional\_matrix\_factorization\_model module
-----------------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.ConvMF.convolutional_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.ConvMF
   :members:
   :undoc-members:
   :show-inheritance:
