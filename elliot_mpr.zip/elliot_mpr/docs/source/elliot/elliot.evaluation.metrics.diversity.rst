elliot.evaluation.metrics.diversity package
===========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics.diversity.SRecall
   elliot.evaluation.metrics.diversity.gini_index
   elliot.evaluation.metrics.diversity.shannon_entropy

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.diversity
   :members:
   :undoc-members:
   :show-inheritance:
