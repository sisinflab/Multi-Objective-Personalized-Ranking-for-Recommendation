elliot.recommender.neural.DMF package
=====================================

Submodules
----------

elliot.recommender.neural.DMF.deep\_matrix\_factorization module
----------------------------------------------------------------

.. automodule:: elliot.recommender.neural.DMF.deep_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.DMF.deep\_matrix\_factorization\_model module
-----------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.DMF.deep_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.DMF
   :members:
   :undoc-members:
   :show-inheritance:
