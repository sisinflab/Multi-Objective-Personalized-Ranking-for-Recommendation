elliot.evaluation.metrics.coverage.user\_coverage package
=========================================================

Submodules
----------

elliot.evaluation.metrics.coverage.user\_coverage.user\_coverage module
-----------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.coverage.user_coverage.user_coverage
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.coverage.user\_coverage.user\_coverage\_at\_n module
------------------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.coverage.user_coverage.user_coverage_at_n
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.coverage.user_coverage
   :members:
   :undoc-members:
   :show-inheritance:
