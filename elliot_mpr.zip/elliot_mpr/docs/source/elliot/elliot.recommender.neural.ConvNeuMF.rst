elliot.recommender.neural.ConvNeuMF package
===========================================

Submodules
----------

elliot.recommender.neural.ConvNeuMF.convolutional\_neural\_matrix\_factorization module
---------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.ConvNeuMF.convolutional_neural_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.ConvNeuMF.convolutional\_neural\_matrix\_factorization\_model module
----------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.ConvNeuMF.convolutional_neural_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.ConvNeuMF
   :members:
   :undoc-members:
   :show-inheritance:
