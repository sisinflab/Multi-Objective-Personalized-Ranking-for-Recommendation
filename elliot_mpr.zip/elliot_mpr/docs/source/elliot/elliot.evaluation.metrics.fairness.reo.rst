elliot.evaluation.metrics.fairness.reo package
==============================================

Submodules
----------

elliot.evaluation.metrics.fairness.reo.reo module
-------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.reo.reo
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.fairness.reo
   :members:
   :undoc-members:
   :show-inheritance:
