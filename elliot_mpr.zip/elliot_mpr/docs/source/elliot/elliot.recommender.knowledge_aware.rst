elliot.recommender.knowledge\_aware package
===========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.knowledge_aware.kaHFM
   elliot.recommender.knowledge_aware.kaHFM_batch
   elliot.recommender.knowledge_aware.kahfm_embeddings

Module contents
---------------

.. automodule:: elliot.recommender.knowledge_aware
   :members:
   :undoc-members:
   :show-inheritance:
