elliot.evaluation.relevance package
===================================

Submodules
----------

elliot.evaluation.relevance.relevance module
--------------------------------------------

.. automodule:: elliot.evaluation.relevance.relevance
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.relevance
   :members:
   :undoc-members:
   :show-inheritance:
