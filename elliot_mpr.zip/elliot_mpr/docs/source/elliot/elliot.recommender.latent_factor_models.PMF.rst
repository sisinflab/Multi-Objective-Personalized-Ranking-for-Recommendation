elliot.recommender.latent\_factor\_models.PMF package
=====================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.PMF.probabilistic\_matrix\_factorization module
-----------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.PMF.probabilistic_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.PMF.probabilistic\_matrix\_factorization\_model module
------------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.PMF.probabilistic_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.PMF
   :members:
   :undoc-members:
   :show-inheritance:
