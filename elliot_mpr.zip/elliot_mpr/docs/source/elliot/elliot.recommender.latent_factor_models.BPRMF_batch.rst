elliot.recommender.latent\_factor\_models.BPRMF\_batch package
==============================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.BPRMF\_batch.BPRMF\_batch module
--------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.BPRMF_batch.BPRMF_batch
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.BPRMF\_batch.BPRMF\_batch\_model module
---------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.BPRMF_batch.BPRMF_batch_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.BPRMF_batch
   :members:
   :undoc-members:
   :show-inheritance:
