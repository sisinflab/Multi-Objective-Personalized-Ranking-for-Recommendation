elliot.dataset package
======================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.dataset.dataloader
   elliot.dataset.samplers

Submodules
----------

elliot.dataset.abstract\_dataset module
---------------------------------------

.. automodule:: elliot.dataset.abstract_dataset
   :members:
   :undoc-members:
   :show-inheritance:

elliot.dataset.dataset module
-----------------------------

.. automodule:: elliot.dataset.dataset
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.dataset
   :members:
   :undoc-members:
   :show-inheritance:
