elliot.evaluation.popularity\_utils package
===========================================

Submodules
----------

elliot.evaluation.popularity\_utils.popularity module
-----------------------------------------------------

.. automodule:: elliot.evaluation.popularity_utils.popularity
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.popularity_utils
   :members:
   :undoc-members:
   :show-inheritance:
