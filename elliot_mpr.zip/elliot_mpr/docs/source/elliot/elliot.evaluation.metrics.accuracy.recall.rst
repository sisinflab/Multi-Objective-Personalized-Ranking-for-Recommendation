elliot.evaluation.metrics.accuracy.recall package
=================================================

Submodules
----------

elliot.evaluation.metrics.accuracy.recall.recall module
-------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.recall.recall
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.recall
   :members:
   :undoc-members:
   :show-inheritance:
