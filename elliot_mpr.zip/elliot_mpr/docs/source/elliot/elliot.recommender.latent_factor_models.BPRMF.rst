elliot.recommender.latent\_factor\_models.BPRMF package
=======================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.BPRMF.BPRMF module
------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.BPRMF.BPRMF
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.BPRMF
   :members:
   :undoc-members:
   :show-inheritance:
