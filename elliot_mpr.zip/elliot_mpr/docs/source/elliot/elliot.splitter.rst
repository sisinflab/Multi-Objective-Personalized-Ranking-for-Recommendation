elliot.splitter package
=======================

Submodules
----------

elliot.splitter.base\_splitter module
-------------------------------------

.. automodule:: elliot.splitter.base_splitter
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.splitter
   :members:
   :undoc-members:
   :show-inheritance:
