elliot.evaluation.metrics.accuracy.mar package
==============================================

Submodules
----------

elliot.evaluation.metrics.accuracy.mar.mar module
-------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.mar.mar
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.mar
   :members:
   :undoc-members:
   :show-inheritance:
