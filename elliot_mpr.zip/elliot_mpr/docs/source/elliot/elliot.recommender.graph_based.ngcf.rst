elliot.recommender.graph\_based.ngcf package
============================================

Submodules
----------

elliot.recommender.graph\_based.ngcf.NGCF module
------------------------------------------------

.. automodule:: elliot.recommender.graph_based.ngcf.NGCF
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.graph\_based.ngcf.NGCF\_model module
-------------------------------------------------------

.. automodule:: elliot.recommender.graph_based.ngcf.NGCF_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.graph_based.ngcf
   :members:
   :undoc-members:
   :show-inheritance:
