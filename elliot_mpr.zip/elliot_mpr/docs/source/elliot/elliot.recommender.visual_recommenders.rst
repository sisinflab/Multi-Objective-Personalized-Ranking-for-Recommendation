elliot.recommender.visual\_recommenders package
===============================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.visual_recommenders.ACF
   elliot.recommender.visual_recommenders.DVBPR
   elliot.recommender.visual_recommenders.DeepStyle
   elliot.recommender.visual_recommenders.VBPR
   elliot.recommender.visual_recommenders.VNPR

Module contents
---------------

.. automodule:: elliot.recommender.visual_recommenders
   :members:
   :undoc-members:
   :show-inheritance:
