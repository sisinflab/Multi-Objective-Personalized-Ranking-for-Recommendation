elliot.recommender.visual\_recommenders.VBPR package
====================================================

Submodules
----------

elliot.recommender.visual\_recommenders.VBPR.VBPR module
--------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.VBPR.VBPR
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.visual\_recommenders.VBPR.VBPR\_model module
---------------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.VBPR.VBPR_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.visual_recommenders.VBPR
   :members:
   :undoc-members:
   :show-inheritance:
