elliot.recommender.knn.attribute\_user\_knn package
==================================================

Submodules
----------

elliot.recommender.knn.attribute\_user\_knn.attribute\_user\_knn module
----------------------------------------------------------------------

.. automodule:: elliot.recommender.knn.attribute_user_knn.attribute_user_knn
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knn.attribute\_user\_knn.attribute\_user\_knn\_similarity module
----------------------------------------------------------------------------------

.. automodule:: elliot.recommender.knn.attribute_user_knn.attribute_user_knn_similarity
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knn.attribute\_user\_knn.tfidf\_utils module
--------------------------------------------------------------

.. automodule:: elliot.recommender.knn.attribute_user_knn.tfidf_utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.knn.attribute_user_knn
   :members:
   :undoc-members:
   :show-inheritance:
