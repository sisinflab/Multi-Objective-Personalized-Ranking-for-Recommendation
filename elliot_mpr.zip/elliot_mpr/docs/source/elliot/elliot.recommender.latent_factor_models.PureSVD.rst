elliot.recommender.latent\_factor\_models.PureSVD package
=========================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.PureSVD.pure\_svd module
------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.PureSVD.pure_svd
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.PureSVD.pure\_svd\_model module
-------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.PureSVD.pure_svd_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.PureSVD
   :members:
   :undoc-members:
   :show-inheritance:
