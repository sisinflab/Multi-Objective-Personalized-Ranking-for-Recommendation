elliot.evaluation.metrics.accuracy.DSC package
==============================================

Submodules
----------

elliot.evaluation.metrics.accuracy.DSC.dsc module
-------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.DSC.dsc
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.DSC
   :members:
   :undoc-members:
   :show-inheritance:
