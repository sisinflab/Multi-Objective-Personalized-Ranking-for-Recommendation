elliot.recommender.neural.NAIS package
======================================

Submodules
----------

elliot.recommender.neural.NAIS.nais module
------------------------------------------

.. automodule:: elliot.recommender.neural.NAIS.nais
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.NAIS.nais\_model module
-------------------------------------------------

.. automodule:: elliot.recommender.neural.NAIS.nais_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.NAIS
   :members:
   :undoc-members:
   :show-inheritance:
