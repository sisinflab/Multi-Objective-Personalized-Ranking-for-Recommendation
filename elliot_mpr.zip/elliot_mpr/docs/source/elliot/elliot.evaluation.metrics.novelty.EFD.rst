elliot.evaluation.metrics.novelty.EFD package
=============================================

Submodules
----------

elliot.evaluation.metrics.novelty.EFD.efd module
------------------------------------------------

.. automodule:: elliot.evaluation.metrics.novelty.EFD.efd
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.novelty.EFD.extended\_efd module
----------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.novelty.EFD.extended_efd
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.novelty.EFD
   :members:
   :undoc-members:
   :show-inheritance:
