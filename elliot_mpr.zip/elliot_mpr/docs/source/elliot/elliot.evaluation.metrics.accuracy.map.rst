elliot.evaluation.metrics.accuracy.map package
==============================================

Submodules
----------

elliot.evaluation.metrics.accuracy.map.map module
-------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.map.map
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.map
   :members:
   :undoc-members:
   :show-inheritance:
