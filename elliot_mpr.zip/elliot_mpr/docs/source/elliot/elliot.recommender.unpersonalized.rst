elliot.recommender.unpersonalized package
=========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.unpersonalized.most_popular
   elliot.recommender.unpersonalized.random_recommender

Module contents
---------------

.. automodule:: elliot.recommender.unpersonalized
   :members:
   :undoc-members:
   :show-inheritance:
