elliot.recommender.gan package
==============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.gan.CFGAN
   elliot.recommender.gan.IRGAN

Module contents
---------------

.. automodule:: elliot.recommender.gan
   :members:
   :undoc-members:
   :show-inheritance:
