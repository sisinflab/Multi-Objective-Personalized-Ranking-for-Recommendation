elliot package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.dataset
   elliot.evaluation
   elliot.hyperoptimization
   elliot.namespace
   elliot.prefiltering
   elliot.recommender
   elliot.result_handler
   elliot.splitter
   elliot.utils

Submodules
----------

elliot.run module
-----------------

.. automodule:: elliot.run
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot
   :members:
   :undoc-members:
   :show-inheritance:
