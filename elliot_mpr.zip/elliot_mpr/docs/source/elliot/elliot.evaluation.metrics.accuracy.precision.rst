elliot.evaluation.metrics.accuracy.precision package
====================================================

Submodules
----------

elliot.evaluation.metrics.accuracy.precision.precision module
-------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.precision.precision
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.precision
   :members:
   :undoc-members:
   :show-inheritance:
