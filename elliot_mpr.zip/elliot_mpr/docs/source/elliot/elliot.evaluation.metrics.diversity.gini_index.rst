elliot.evaluation.metrics.diversity.gini\_index package
=======================================================

Submodules
----------

elliot.evaluation.metrics.diversity.gini\_index.gini\_index module
------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.diversity.gini_index.gini_index
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.diversity.gini_index
   :members:
   :undoc-members:
   :show-inheritance:
