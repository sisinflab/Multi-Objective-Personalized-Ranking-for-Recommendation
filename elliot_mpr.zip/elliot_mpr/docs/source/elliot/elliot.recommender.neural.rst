elliot.recommender.neural package
=================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.neural.ConvMF
   elliot.recommender.neural.ConvNeuMF
   elliot.recommender.neural.DMF
   elliot.recommender.neural.DeepFM
   elliot.recommender.neural.GeneralizedMF
   elliot.recommender.neural.ItemAutoRec
   elliot.recommender.neural.NAIS
   elliot.recommender.neural.NFM
   elliot.recommender.neural.NPR
   elliot.recommender.neural.NeuMF
   elliot.recommender.neural.UserAutoRec
   elliot.recommender.neural.WideAndDeep

Module contents
---------------

.. automodule:: elliot.recommender.neural
   :members:
   :undoc-members:
   :show-inheritance:
