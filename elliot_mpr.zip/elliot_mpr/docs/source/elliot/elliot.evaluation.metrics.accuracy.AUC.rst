elliot.evaluation.metrics.accuracy.AUC package
==============================================

Submodules
----------

elliot.evaluation.metrics.accuracy.AUC.auc module
-------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.AUC.auc
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.accuracy.AUC.gauc module
--------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.AUC.gauc
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.accuracy.AUC.lauc module
--------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.AUC.lauc
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.AUC
   :members:
   :undoc-members:
   :show-inheritance:
