elliot.recommender.neural.UserAutoRec package
=============================================

Submodules
----------

elliot.recommender.neural.UserAutoRec.userautorec module
--------------------------------------------------------

.. automodule:: elliot.recommender.neural.UserAutoRec.userautorec
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.UserAutoRec.userautorec\_model module
---------------------------------------------------------------

.. automodule:: elliot.recommender.neural.UserAutoRec.userautorec_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.UserAutoRec
   :members:
   :undoc-members:
   :show-inheritance:
