elliot.recommender.visual\_recommenders.DeepStyle package
=========================================================

Submodules
----------

elliot.recommender.visual\_recommenders.DeepStyle.DeepStyle module
------------------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.DeepStyle.DeepStyle
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.visual\_recommenders.DeepStyle.DeepStyle\_model module
-------------------------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.DeepStyle.DeepStyle_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.visual_recommenders.DeepStyle
   :members:
   :undoc-members:
   :show-inheritance:
