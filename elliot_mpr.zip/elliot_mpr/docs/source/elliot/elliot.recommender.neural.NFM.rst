elliot.recommender.neural.NFM package
=====================================

Submodules
----------

elliot.recommender.neural.NFM.neural\_fm module
-----------------------------------------------

.. automodule:: elliot.recommender.neural.NFM.neural_fm
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.NFM.neural\_fm\_model module
------------------------------------------------------

.. automodule:: elliot.recommender.neural.NFM.neural_fm_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.NFM
   :members:
   :undoc-members:
   :show-inheritance:
