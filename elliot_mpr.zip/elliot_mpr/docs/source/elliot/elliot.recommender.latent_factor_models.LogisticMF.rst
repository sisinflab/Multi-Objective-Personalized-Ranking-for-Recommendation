elliot.recommender.latent\_factor\_models.LogisticMF package
============================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.LogisticMF.logistic\_matrix\_factorization module
-------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.LogisticMF.logistic_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.LogisticMF.logistic\_matrix\_factorization\_model module
--------------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.LogisticMF.logistic_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.LogisticMF
   :members:
   :undoc-members:
   :show-inheritance:
