elliot.recommender.algebric package
===================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.algebric.slope_one

Module contents
---------------

.. automodule:: elliot.recommender.algebric
   :members:
   :undoc-members:
   :show-inheritance:
