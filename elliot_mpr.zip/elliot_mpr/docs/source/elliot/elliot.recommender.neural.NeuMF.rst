elliot.recommender.neural.NeuMF package
=======================================

Submodules
----------

elliot.recommender.neural.NeuMF.neural\_matrix\_factorization module
--------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.NeuMF.neural_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.NeuMF.neural\_matrix\_factorization\_model module
---------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.NeuMF.neural_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.NeuMF
   :members:
   :undoc-members:
   :show-inheritance:
