elliot.recommender.knn.user\_knn package
=======================================

Submodules
----------

elliot.recommender.knn.user\_knn.aiolli\_ferrari module
------------------------------------------------------

.. automodule:: elliot.recommender.knn.user_knn.aiolli_ferrari
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knn.user\_knn.user\_knn module
------------------------------------------------

.. automodule:: elliot.recommender.knn.user_knn.user_knn
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knn.user\_knn.user\_knn\_similarity module
------------------------------------------------------------

.. automodule:: elliot.recommender.knn.user_knn.user_knn_similarity
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.knn.user_knn
   :members:
   :undoc-members:
   :show-inheritance:
