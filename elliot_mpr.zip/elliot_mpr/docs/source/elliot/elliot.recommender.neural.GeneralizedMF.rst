elliot.recommender.neural.GeneralizedMF package
===============================================

Submodules
----------

elliot.recommender.neural.GeneralizedMF.generalized\_matrix\_factorization module
---------------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.GeneralizedMF.generalized_matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.GeneralizedMF.generalized\_matrix\_factorization\_model module
----------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.GeneralizedMF.generalized_matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.GeneralizedMF
   :members:
   :undoc-members:
   :show-inheritance:
