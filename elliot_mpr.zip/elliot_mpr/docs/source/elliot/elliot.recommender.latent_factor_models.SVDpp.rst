elliot.recommender.latent\_factor\_models.SVDpp package
=======================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.SVDpp.svdpp module
------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.SVDpp.svdpp
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.SVDpp.svdpp\_model module
-------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.SVDpp.svdpp_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.SVDpp
   :members:
   :undoc-members:
   :show-inheritance:
