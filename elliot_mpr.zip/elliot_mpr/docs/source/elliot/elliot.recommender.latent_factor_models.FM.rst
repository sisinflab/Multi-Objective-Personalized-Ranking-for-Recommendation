elliot.recommender.latent\_factor\_models.FM package
====================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.FM.factorization\_machine module
--------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FM.factorization_machine
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.FM.factorization\_machine\_model module
---------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FM.factorization_machine_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.FM
   :members:
   :undoc-members:
   :show-inheritance:
