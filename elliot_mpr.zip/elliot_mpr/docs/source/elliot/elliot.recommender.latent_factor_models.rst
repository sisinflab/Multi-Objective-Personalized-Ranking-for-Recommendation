elliot.recommender.latent\_factor\_models package
=================================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.latent_factor_models.BPRMF
   elliot.recommender.latent_factor_models.BPRMF_batch
   elliot.recommender.latent_factor_models.BPRSlim
   elliot.recommender.latent_factor_models.CML
   elliot.recommender.latent_factor_models.FFM
   elliot.recommender.latent_factor_models.FISM
   elliot.recommender.latent_factor_models.FM
   elliot.recommender.latent_factor_models.FunkSVD
   elliot.recommender.latent_factor_models.LogisticMF
   elliot.recommender.latent_factor_models.MF
   elliot.recommender.latent_factor_models.NonNegMF
   elliot.recommender.latent_factor_models.PMF
   elliot.recommender.latent_factor_models.PureSVD
   elliot.recommender.latent_factor_models.SVDpp
   elliot.recommender.latent_factor_models.Slim
   elliot.recommender.latent_factor_models.WRMF

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models
   :members:
   :undoc-members:
   :show-inheritance:
