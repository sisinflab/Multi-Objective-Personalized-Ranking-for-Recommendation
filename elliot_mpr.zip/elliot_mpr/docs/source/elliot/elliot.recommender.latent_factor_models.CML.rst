elliot.recommender.latent\_factor\_models.CML package
=====================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.CML.CML module
--------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.CML.CML
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.CML.CML\_model module
---------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.CML.CML_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.CML
   :members:
   :undoc-members:
   :show-inheritance:
