elliot.evaluation.metrics.bias package
======================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics.bias.aclt
   elliot.evaluation.metrics.bias.aplt
   elliot.evaluation.metrics.bias.arp
   elliot.evaluation.metrics.bias.pop_reo
   elliot.evaluation.metrics.bias.pop_rsp

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.bias
   :members:
   :undoc-members:
   :show-inheritance:
