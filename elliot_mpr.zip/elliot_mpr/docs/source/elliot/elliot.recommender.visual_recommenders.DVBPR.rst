elliot.recommender.visual\_recommenders.DVBPR package
=====================================================

Submodules
----------

elliot.recommender.visual\_recommenders.DVBPR.DVBPR module
----------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.DVBPR.DVBPR
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.visual\_recommenders.DVBPR.DVBPR\_model module
-----------------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.DVBPR.DVBPR_model
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.visual\_recommenders.DVBPR.FeatureExtractor module
---------------------------------------------------------------------

.. automodule:: elliot.recommender.visual_recommenders.DVBPR.FeatureExtractor
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.visual_recommenders.DVBPR
   :members:
   :undoc-members:
   :show-inheritance:
