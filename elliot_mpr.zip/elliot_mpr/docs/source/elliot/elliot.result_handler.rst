elliot.result\_handler package
==============================

Submodules
----------

elliot.result\_handler.result\_handler module
---------------------------------------------

.. automodule:: elliot.result_handler.result_handler
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.result_handler
   :members:
   :undoc-members:
   :show-inheritance:
