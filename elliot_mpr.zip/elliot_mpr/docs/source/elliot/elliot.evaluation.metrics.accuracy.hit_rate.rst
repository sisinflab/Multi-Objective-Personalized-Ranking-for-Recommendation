elliot.evaluation.metrics.accuracy.hit\_rate package
====================================================

Submodules
----------

elliot.evaluation.metrics.accuracy.hit\_rate.hit\_rate module
-------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.hit_rate.hit_rate
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.hit_rate
   :members:
   :undoc-members:
   :show-inheritance:
