elliot.recommender.adversarial.AMR package
==========================================

Submodules
----------

elliot.recommender.adversarial.AMR.AMR module
---------------------------------------------

.. automodule:: elliot.recommender.adversarial.AMR.AMR
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.adversarial.AMR.AMR\_model module
----------------------------------------------------

.. automodule:: elliot.recommender.adversarial.AMR.AMR_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.adversarial.AMR
   :members:
   :undoc-members:
   :show-inheritance:
