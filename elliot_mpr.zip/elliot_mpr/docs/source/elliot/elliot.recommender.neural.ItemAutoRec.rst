elliot.recommender.neural.ItemAutoRec package
=============================================

Submodules
----------

elliot.recommender.neural.ItemAutoRec.itemautorec module
--------------------------------------------------------

.. automodule:: elliot.recommender.neural.ItemAutoRec.itemautorec
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.ItemAutoRec.itemautorec\_model module
---------------------------------------------------------------

.. automodule:: elliot.recommender.neural.ItemAutoRec.itemautorec_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.ItemAutoRec
   :members:
   :undoc-members:
   :show-inheritance:
