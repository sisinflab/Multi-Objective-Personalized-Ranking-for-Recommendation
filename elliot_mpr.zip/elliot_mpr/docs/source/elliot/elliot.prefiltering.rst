elliot.prefiltering package
===========================

Submodules
----------

elliot.prefiltering.standard\_prefilters module
-----------------------------------------------

.. automodule:: elliot.prefiltering.standard_prefilters
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.prefiltering
   :members:
   :undoc-members:
   :show-inheritance:
