elliot.recommender.graph\_based.lightgcn package
================================================

Submodules
----------

elliot.recommender.graph\_based.lightgcn.LightGCN module
--------------------------------------------------------

.. automodule:: elliot.recommender.graph_based.lightgcn.LightGCN
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.graph\_based.lightgcn.LightGCN\_model module
---------------------------------------------------------------

.. automodule:: elliot.recommender.graph_based.lightgcn.LightGCN_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.graph_based.lightgcn
   :members:
   :undoc-members:
   :show-inheritance:
