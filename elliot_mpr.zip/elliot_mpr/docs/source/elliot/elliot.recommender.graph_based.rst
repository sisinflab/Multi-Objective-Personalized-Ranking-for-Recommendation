elliot.recommender.graph\_based package
=======================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.graph_based.lightgcn
   elliot.recommender.graph_based.ngcf

Module contents
---------------

.. automodule:: elliot.recommender.graph_based
   :members:
   :undoc-members:
   :show-inheritance:
