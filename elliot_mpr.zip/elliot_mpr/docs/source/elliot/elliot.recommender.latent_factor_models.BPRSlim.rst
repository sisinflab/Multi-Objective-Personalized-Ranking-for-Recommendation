elliot.recommender.latent\_factor\_models.BPRSlim package
=========================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.BPRSlim.bprslim module
----------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.BPRSlim.bprslim
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.BPRSlim.bprslim\_model module
-----------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.BPRSlim.bprslim_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.BPRSlim
   :members:
   :undoc-members:
   :show-inheritance:
