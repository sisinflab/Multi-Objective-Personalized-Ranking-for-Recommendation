elliot.evaluation.metrics.fairness package
==========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics.fairness.BiasDisparity
   elliot.evaluation.metrics.fairness.MAD
   elliot.evaluation.metrics.fairness.reo
   elliot.evaluation.metrics.fairness.rsp

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.fairness
   :members:
   :undoc-members:
   :show-inheritance:
