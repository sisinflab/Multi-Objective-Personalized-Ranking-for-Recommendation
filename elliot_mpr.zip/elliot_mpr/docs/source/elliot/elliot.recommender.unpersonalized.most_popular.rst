elliot.recommender.unpersonalized.most\_popular package
=======================================================

Submodules
----------

elliot.recommender.unpersonalized.most\_popular.most\_popular module
--------------------------------------------------------------------

.. automodule:: elliot.recommender.unpersonalized.most_popular.most_popular
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.unpersonalized.most_popular
   :members:
   :undoc-members:
   :show-inheritance:
