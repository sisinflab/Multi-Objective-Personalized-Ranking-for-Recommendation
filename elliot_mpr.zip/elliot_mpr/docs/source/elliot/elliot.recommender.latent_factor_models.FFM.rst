elliot.recommender.latent\_factor\_models.FFM package
=====================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.FFM.field\_aware\_factorization\_machine module
-----------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FFM.field_aware_factorization_machine
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.FFM.field\_aware\_factorization\_machine\_model module
------------------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FFM.field_aware_factorization_machine_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.FFM
   :members:
   :undoc-members:
   :show-inheritance:
