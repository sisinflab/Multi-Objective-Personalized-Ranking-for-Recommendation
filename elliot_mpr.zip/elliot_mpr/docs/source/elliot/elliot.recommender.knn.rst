elliot.recommender.knn package
=============================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.knn.attribute_item_knn
   elliot.recommender.knn.attribute_user_knn
   elliot.recommender.knn.item_knn
   elliot.recommender.knn.user_knn

Module contents
---------------

.. automodule:: elliot.recommender.knn
   :members:
   :undoc-members:
   :show-inheritance:
