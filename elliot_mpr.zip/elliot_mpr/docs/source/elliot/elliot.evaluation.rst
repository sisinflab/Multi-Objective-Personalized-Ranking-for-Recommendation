elliot.evaluation package
=========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics
   elliot.evaluation.popularity_utils
   elliot.evaluation.relevance

Submodules
----------

elliot.evaluation.evaluator module
----------------------------------

.. automodule:: elliot.evaluation.evaluator
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.statistical\_significance module
--------------------------------------------------

.. automodule:: elliot.evaluation.statistical_significance
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation
   :members:
   :undoc-members:
   :show-inheritance:
