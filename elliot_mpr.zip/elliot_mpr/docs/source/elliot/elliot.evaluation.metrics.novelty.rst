elliot.evaluation.metrics.novelty package
=========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics.novelty.EFD
   elliot.evaluation.metrics.novelty.EPC

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.novelty
   :members:
   :undoc-members:
   :show-inheritance:
