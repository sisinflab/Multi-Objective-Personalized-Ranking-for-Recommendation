elliot.recommender.knowledge\_aware.kaHFM\_batch package
========================================================

Submodules
----------

elliot.recommender.knowledge\_aware.kaHFM\_batch.kahfm\_batch module
--------------------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kaHFM_batch.kahfm_batch
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knowledge\_aware.kaHFM\_batch.kahfm\_batch\_model module
---------------------------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kaHFM_batch.kahfm_batch_model
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knowledge\_aware.kaHFM\_batch.tfidf\_utils module
--------------------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kaHFM_batch.tfidf_utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.knowledge_aware.kaHFM_batch
   :members:
   :undoc-members:
   :show-inheritance:
