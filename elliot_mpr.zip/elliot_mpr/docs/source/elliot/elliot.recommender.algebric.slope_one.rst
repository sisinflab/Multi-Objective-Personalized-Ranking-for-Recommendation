elliot.recommender.algebric.slope\_one package
==============================================

Submodules
----------

elliot.recommender.algebric.slope\_one.slope\_one module
--------------------------------------------------------

.. automodule:: elliot.recommender.algebric.slope_one.slope_one
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.algebric.slope\_one.slope\_one\_model module
---------------------------------------------------------------

.. automodule:: elliot.recommender.algebric.slope_one.slope_one_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.algebric.slope_one
   :members:
   :undoc-members:
   :show-inheritance:
