elliot.recommender.neural.NPR package
=====================================

Submodules
----------

elliot.recommender.neural.NPR.neural\_personalized\_ranking module
------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.NPR.neural_personalized_ranking
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.NPR.neural\_personalized\_ranking\_model module
-------------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.NPR.neural_personalized_ranking_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.NPR
   :members:
   :undoc-members:
   :show-inheritance:
