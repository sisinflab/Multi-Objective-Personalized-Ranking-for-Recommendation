elliot.evaluation.metrics.novelty.EPC package
=============================================

Submodules
----------

elliot.evaluation.metrics.novelty.EPC.epc module
------------------------------------------------

.. automodule:: elliot.evaluation.metrics.novelty.EPC.epc
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.novelty.EPC.extended\_epc module
----------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.novelty.EPC.extended_epc
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.novelty.EPC
   :members:
   :undoc-members:
   :show-inheritance:
