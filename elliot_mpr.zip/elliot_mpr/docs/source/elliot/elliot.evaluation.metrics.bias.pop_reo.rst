elliot.evaluation.metrics.bias.pop\_reo package
===============================================

Submodules
----------

elliot.evaluation.metrics.bias.pop\_reo.extended\_pop\_reo module
-----------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.bias.pop_reo.extended_pop_reo
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.bias.pop\_reo.pop\_reo module
-------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.bias.pop_reo.pop_reo
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.bias.pop_reo
   :members:
   :undoc-members:
   :show-inheritance:
