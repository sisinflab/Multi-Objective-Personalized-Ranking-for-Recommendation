elliot.evaluation.metrics.rating package
========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics.rating.mae
   elliot.evaluation.metrics.rating.mse
   elliot.evaluation.metrics.rating.rmse

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.rating
   :members:
   :undoc-members:
   :show-inheritance:
