elliot.recommender.latent\_factor\_models.WRMF package
======================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.WRMF.wrmf module
----------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.WRMF.wrmf
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.WRMF.wrmf\_model module
-----------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.WRMF.wrmf_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.WRMF
   :members:
   :undoc-members:
   :show-inheritance:
