elliot.recommender.content\_based.VSM package
=============================================

Submodules
----------

elliot.recommender.content\_based.VSM.tfidf\_utils module
---------------------------------------------------------

.. automodule:: elliot.recommender.content_based.VSM.tfidf_utils
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.content\_based.VSM.vector\_space\_model module
-----------------------------------------------------------------

.. automodule:: elliot.recommender.content_based.VSM.vector_space_model
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.content\_based.VSM.vector\_space\_model\_similarity module
-----------------------------------------------------------------------------

.. automodule:: elliot.recommender.content_based.VSM.vector_space_model_similarity
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.content_based.VSM
   :members:
   :undoc-members:
   :show-inheritance:
