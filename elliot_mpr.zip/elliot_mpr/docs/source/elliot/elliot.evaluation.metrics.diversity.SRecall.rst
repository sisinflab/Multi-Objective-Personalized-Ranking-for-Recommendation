elliot.evaluation.metrics.diversity.SRecall package
===================================================

Submodules
----------

elliot.evaluation.metrics.diversity.SRecall.srecall module
----------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.diversity.SRecall.srecall
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.diversity.SRecall
   :members:
   :undoc-members:
   :show-inheritance:
