elliot.recommender.knowledge\_aware.kahfm\_embeddings package
=============================================================

Submodules
----------

elliot.recommender.knowledge\_aware.kahfm\_embeddings.kahfm\_embeddings module
------------------------------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kahfm_embeddings.kahfm_embeddings
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knowledge\_aware.kahfm\_embeddings.kahfm\_embeddings\_model module
-------------------------------------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kahfm_embeddings.kahfm_embeddings_model
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knowledge\_aware.kahfm\_embeddings.tfidf\_utils module
-------------------------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kahfm_embeddings.tfidf_utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.knowledge_aware.kahfm_embeddings
   :members:
   :undoc-members:
   :show-inheritance:
