elliot.recommender.gan.IRGAN package
====================================

Submodules
----------

elliot.recommender.gan.IRGAN.irgan module
-----------------------------------------

.. automodule:: elliot.recommender.gan.IRGAN.irgan
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.gan.IRGAN.irgan\_model module
------------------------------------------------

.. automodule:: elliot.recommender.gan.IRGAN.irgan_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.gan.IRGAN
   :members:
   :undoc-members:
   :show-inheritance:
