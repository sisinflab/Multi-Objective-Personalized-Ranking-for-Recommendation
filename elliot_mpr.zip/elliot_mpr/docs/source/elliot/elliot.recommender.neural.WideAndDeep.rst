elliot.recommender.neural.WideAndDeep package
=============================================

Submodules
----------

elliot.recommender.neural.WideAndDeep.wide\_and\_deep module
------------------------------------------------------------

.. automodule:: elliot.recommender.neural.WideAndDeep.wide_and_deep
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.WideAndDeep.wide\_and\_deep\_model module
-------------------------------------------------------------------

.. automodule:: elliot.recommender.neural.WideAndDeep.wide_and_deep_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.WideAndDeep
   :members:
   :undoc-members:
   :show-inheritance:
