elliot.recommender.autoencoders.vae package
===========================================

Submodules
----------

elliot.recommender.autoencoders.vae.multi\_vae module
-----------------------------------------------------

.. automodule:: elliot.recommender.autoencoders.vae.multi_vae
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.autoencoders.vae.multi\_vae\_model module
------------------------------------------------------------

.. automodule:: elliot.recommender.autoencoders.vae.multi_vae_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.autoencoders.vae
   :members:
   :undoc-members:
   :show-inheritance:
