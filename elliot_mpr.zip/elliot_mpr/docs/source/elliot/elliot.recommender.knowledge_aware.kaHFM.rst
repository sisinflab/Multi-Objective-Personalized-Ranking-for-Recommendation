elliot.recommender.knowledge\_aware.kaHFM package
=================================================

Submodules
----------

elliot.recommender.knowledge\_aware.kaHFM.ka\hfm module
--------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kaHFM.kahfm
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knowledge\_aware.kaHFM.tfidf\_utils module
-------------------------------------------------------------

.. automodule:: elliot.recommender.knowledge_aware.kaHFM.tfidf_utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.knowledge_aware.kaHFM
   :members:
   :undoc-members:
   :show-inheritance:
