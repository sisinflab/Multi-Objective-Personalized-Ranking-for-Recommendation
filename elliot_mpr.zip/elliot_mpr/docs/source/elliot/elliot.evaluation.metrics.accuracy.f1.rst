elliot.evaluation.metrics.accuracy.f1 package
=============================================

Submodules
----------

elliot.evaluation.metrics.accuracy.f1.extended\_f1 module
---------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.f1.extended_f1
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.accuracy.f1.f1 module
-----------------------------------------------

.. automodule:: elliot.evaluation.metrics.accuracy.f1.f1
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.accuracy.f1
   :members:
   :undoc-members:
   :show-inheritance:
