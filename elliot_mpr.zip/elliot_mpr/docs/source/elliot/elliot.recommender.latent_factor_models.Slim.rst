elliot.recommender.latent\_factor\_models.Slim package
======================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.Slim.slim module
----------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.Slim.slim
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.Slim.slim\_model module
-----------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.Slim.slim_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.Slim
   :members:
   :undoc-members:
   :show-inheritance:
