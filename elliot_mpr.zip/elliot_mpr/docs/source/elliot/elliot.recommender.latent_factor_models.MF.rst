elliot.recommender.latent\_factor\_models.MF package
====================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.MF.matrix\_factorization module
-------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.MF.matrix_factorization
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.MF.matrix\_factorization\_model module
--------------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.MF.matrix_factorization_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.MF
   :members:
   :undoc-members:
   :show-inheritance:
