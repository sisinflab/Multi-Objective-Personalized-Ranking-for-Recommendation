elliot.recommender.content\_based package
=========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.content_based.VSM

Module contents
---------------

.. automodule:: elliot.recommender.content_based
   :members:
   :undoc-members:
   :show-inheritance:
