elliot.recommender.knn.item\_knn package
=======================================

Submodules
----------

elliot.recommender.knn.item\_knn.aiolli\_ferrari module
------------------------------------------------------

.. automodule:: elliot.recommender.knn.item_knn.aiolli_ferrari
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knn.item\_knn.item\_knn module
------------------------------------------------

.. automodule:: elliot.recommender.knn.item_knn.item_knn
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.knn.item\_knn.item\_knn\_similarity module
------------------------------------------------------------

.. automodule:: elliot.recommender.knn.item_knn.item_knn_similarity
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.knn.item_knn
   :members:
   :undoc-members:
   :show-inheritance:
