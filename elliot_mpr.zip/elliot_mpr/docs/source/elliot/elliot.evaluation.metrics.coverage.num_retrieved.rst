elliot.evaluation.metrics.coverage.num\_retrieved package
=========================================================

Submodules
----------

elliot.evaluation.metrics.coverage.num\_retrieved.num\_retrieved module
-----------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.coverage.num_retrieved.num_retrieved
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.coverage.num_retrieved
   :members:
   :undoc-members:
   :show-inheritance:
