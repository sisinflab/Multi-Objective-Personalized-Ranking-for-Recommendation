elliot.evaluation.metrics.fairness.BiasDisparity package
========================================================

Submodules
----------

elliot.evaluation.metrics.fairness.BiasDisparity.BiasDisparityBD module
-----------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.BiasDisparity.BiasDisparityBD
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.fairness.BiasDisparity.BiasDisparityBR module
-----------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.BiasDisparity.BiasDisparityBR
   :members:
   :undoc-members:
   :show-inheritance:

elliot.evaluation.metrics.fairness.BiasDisparity.BiasDisparityBS module
-----------------------------------------------------------------------

.. automodule:: elliot.evaluation.metrics.fairness.BiasDisparity.BiasDisparityBS
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.fairness.BiasDisparity
   :members:
   :undoc-members:
   :show-inheritance:
