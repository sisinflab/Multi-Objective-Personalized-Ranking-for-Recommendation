elliot.recommender.unpersonalized.random\_recommender package
=============================================================

Submodules
----------

elliot.recommender.unpersonalized.random\_recommender.Random module
-------------------------------------------------------------------

.. automodule:: elliot.recommender.unpersonalized.random_recommender.Random
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.unpersonalized.random_recommender
   :members:
   :undoc-members:
   :show-inheritance:
