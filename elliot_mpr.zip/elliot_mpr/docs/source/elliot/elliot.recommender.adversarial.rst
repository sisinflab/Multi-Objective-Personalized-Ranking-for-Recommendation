elliot.recommender.adversarial package
======================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.recommender.adversarial.AMF
   elliot.recommender.adversarial.AMR

Module contents
---------------

.. automodule:: elliot.recommender.adversarial
   :members:
   :undoc-members:
   :show-inheritance:
