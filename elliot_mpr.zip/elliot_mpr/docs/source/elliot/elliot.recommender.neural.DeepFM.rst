elliot.recommender.neural.DeepFM package
========================================

Submodules
----------

elliot.recommender.neural.DeepFM.deep\_fm module
------------------------------------------------

.. automodule:: elliot.recommender.neural.DeepFM.deep_fm
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.neural.DeepFM.deep\_fm\_model module
-------------------------------------------------------

.. automodule:: elliot.recommender.neural.DeepFM.deep_fm_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.neural.DeepFM
   :members:
   :undoc-members:
   :show-inheritance:
