elliot.evaluation.metrics.coverage package
==========================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   elliot.evaluation.metrics.coverage.item_coverage
   elliot.evaluation.metrics.coverage.num_retrieved
   elliot.evaluation.metrics.coverage.user_coverage

Module contents
---------------

.. automodule:: elliot.evaluation.metrics.coverage
   :members:
   :undoc-members:
   :show-inheritance:
