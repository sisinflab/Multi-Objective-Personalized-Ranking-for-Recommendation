elliot.recommender.latent\_factor\_models.FunkSVD package
=========================================================

Submodules
----------

elliot.recommender.latent\_factor\_models.FunkSVD.funk\_svd module
------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FunkSVD.funk_svd
   :members:
   :undoc-members:
   :show-inheritance:

elliot.recommender.latent\_factor\_models.FunkSVD.funk\_svd\_model module
-------------------------------------------------------------------------

.. automodule:: elliot.recommender.latent_factor_models.FunkSVD.funk_svd_model
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: elliot.recommender.latent_factor_models.FunkSVD
   :members:
   :undoc-members:
   :show-inheritance:
