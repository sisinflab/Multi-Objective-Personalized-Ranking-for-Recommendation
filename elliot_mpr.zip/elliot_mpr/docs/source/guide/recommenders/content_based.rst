Content-Based
======================

.. py:module:: elliot.recommender.content_based


Summary
~~~~~~~~~~~~~~~~

.. autosummary::

    VSM.vector_space_model.VSM

VSM
~~~~~~~~~~~~~~~~

.. module:: elliot.recommender.content_based.VSM.vector_space_model
.. autoclass:: VSM
    :show-inheritance: