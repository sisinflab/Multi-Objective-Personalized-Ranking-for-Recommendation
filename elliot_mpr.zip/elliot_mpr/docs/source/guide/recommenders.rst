Recommendation Models
======================

.. toctree::
   :maxdepth: 1

   recommenders/adversarial
   recommenders/algebric
   recommenders/autoencoders
   recommenders/content_based
   recommenders/gan
   recommenders/graph_based
   recommenders/knowledge_aware
   recommenders/latent_factor_models
   recommenders/neural
   recommenders/knn
   recommenders/unpersonalized
   recommenders/visual_recommenders
