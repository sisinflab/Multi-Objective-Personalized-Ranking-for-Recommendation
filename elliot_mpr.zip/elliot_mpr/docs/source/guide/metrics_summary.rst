Metrics Summary
======================

.. toctree::
   :maxdepth: 1

   metrics/accuracy
   metrics/rating
   metrics/coverage
   metrics/novelty
   metrics/diversity
   metrics/bias
   metrics/fairness
