from .neural_personalized_ranking import NPR
