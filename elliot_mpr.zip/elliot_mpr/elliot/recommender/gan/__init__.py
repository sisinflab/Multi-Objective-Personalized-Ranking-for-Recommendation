from .IRGAN import IRGAN
from .CFGAN import CFGAN